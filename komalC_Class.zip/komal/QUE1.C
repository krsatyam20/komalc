#include<stdio.h>
#include<conio.h>
void main(){
clrscr();
int a,b,c;
char d;
a=20; //(Roll no)
b=50; //(Phone no.)
c=70; //(Marks)
d='k';
printf("value of a(%d)\n",a);
printf("value of b (%d)\n",b);
printf ("value of c (%d)\n",c);

printf("value ofd (%c)",d);




getch();
}