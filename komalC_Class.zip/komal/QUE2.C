#include<stdio.h>
#include<conio.h>

void main(){

clrscr();

int a=5;

int c;
c= a*a;

printf("Square of a = %d",c);




getch();


}
