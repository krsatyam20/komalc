#include<stdio.h>
#include<conio.h>
void main(){
clrscr();
 int a,b,c;

 a=40;
 b=20;

//add
c= a+b;
printf("add value of a and b =%d",c);
//Sub
c= a-b;
printf("add value of a and b =%d",c);

getch();

}