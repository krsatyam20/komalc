//single line comment
/* multiple line comment
this code is writen by komal
commented code is ignored by compiler.
short key for code compile: alt+f9
short key for code run after compile: ctrl+f9
*/

#include<stdio.h> //for standared input and out put
#include<conio.h> //For console screen


void main(){  // here void means no return any things or it`s is a data type
clrscr();// for clear previous data from screen
printf("==============*********===============\n");
printf("Hello Komal");  // printf is a function which is used for print any things
printf("\ngood evning Komal\n");// \n for new line
printf("==============*********===============");
getch(); //use for hold console screen

}