#include <iostream>
#include <fstream>
using namespace std;
int main () {

  ofstream filestream("komalFile.txt");

  if (filestream.is_open())
  {
    filestream << "Welcome to Komal.\n";
    filestream << "File Stream .\n";
    filestream << "Good morning Komal.\n";
    filestream.close();
  }
  else{ cout <<"File opening is fail.";
}



//Read file

   ifstream is;
   string line;
   is.open("komalFile.txt");

   cout << "Reading from a text file:" << endl;

   while(getline(is,line))
   {
   cout << line << endl;
   }
   is.close();
  return 0;
}
