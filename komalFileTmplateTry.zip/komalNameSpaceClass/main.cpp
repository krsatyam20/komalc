#include <iostream>

using namespace std;

namespace a{

void hello(){
cout<<"Hello komal";

}

}
int main()
{
using namespace a;
hello();


    return 0;
}
